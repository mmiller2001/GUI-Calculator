﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace realCalculator
{
    public partial class Form1 : Form
    {
        private string line = ""; // string that will handle math operations
        private string upper = ""; // string that will contain original equation
        private string lower = ""; // string that contains output at the end
        public Form1()
        {
            InitializeComponent();
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower; // initializing so only lines ----- are in output
            textBox1.TextAlign = HorizontalAlignment.Right;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        // all buttons add to string line while being replaced with this.upper to modify printing behavior
        private void zero(object sender, EventArgs e)
        {
            this.line += "0";
            this.upper = this.line;
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }

        private void one(object sender, EventArgs e)
        {
            this.line += "1";
            this.upper = this.line;
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }

        private void two(object sender, EventArgs e)
        {
            this.line += "2";
            this.upper = this.line;
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }

        private void three(object sender, EventArgs e)
        {
            this.line += "3";
            this.upper = this.line;
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }

        private void four(object sender, EventArgs e)
        {
            this.line += "4";
            this.upper = this.line;
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }

        private void five(object sender, EventArgs e)
        {
            this.line += "5";
            this.upper = this.line;
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }

        private void six(object sender, EventArgs e)
        {
            this.line += "6";
            this.upper = this.line;
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }

        private void seven(object sender, EventArgs e)
        {
            this.line += "7";
            this.upper = this.line;
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }

        private void eight(object sender, EventArgs e)
        {
            this.line += "8";
            this.upper = this.line;
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }

        private void nine(object sender, EventArgs e)
        {
            this.line += "9";
            this.upper = this.line;
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }

        private void decimalPeriod(object sender, EventArgs e)
        {
            this.line += ".";
            this.upper = this.line;
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }

        public double Operations(int i, double newNum, string number)
        {
            if (i == 0) // multiplication presented
                newNum *= Convert.ToDouble(number);
            else if (i == 1) // division presented
                newNum /= Math.Round(Convert.ToDouble(number), 2);
            else if (i == 2) // mod presented
                newNum %= Convert.ToDouble(number);
            else if (i == 3) // addition presented
                newNum += Convert.ToDouble(number);
            else // else it would be subtraction
                newNum -= Convert.ToDouble(number);

            return newNum;
        }
        public string newString(double newNum, string left, string right)
        {
            return left+newNum+right;
        }
        private void equal(object sender, EventArgs e)
        {
            char[] arraySymbols = { '*', '/', '%', '+', '-' }; // array operations in order of precedence

            for (int i = 0; i < arraySymbols.Length; i++) // begins with arraySymbols
            {
                string leftString = ""; // leftString will hold left equation values
                string number = ""; // string that will hold number being operated

                for (int j = 0; j < this.line.Length; j++)
                {
                    string rightString = ""; // stores the right part of the equation
                    if (this.line[j] == arraySymbols[i] && number != "") // found operations being looked for
                    {
                        double newNum = Convert.ToDouble(number); // string number becomes a double number
                        number = ""; // emptied to find right number

                        for (int k = j + 1; k < this.line.Length; k++) // begins search for next number to operate
                        {
                            bool negative = false; // possible negative number after the operation

                            // if it contains a '-' and only after the operation, then it is a negative number
                            if ((this.line[k] == '-' && k == j + 1))
                                negative = true;
                            // character must not be a digit or a decimal point and there must not be a negative extra value
                            if ((!Char.IsDigit(this.line[k]) && this.line[k] != '.') && negative == false) 
                            {
                                for (int m = k; m < this.line.Length; m++) // stores right part of the string
                                    rightString += this.line[m];
                                break;
                            }
                            number += this.line[k]; // continues to store right number
                        }

                        newNum = Operations(i, newNum, number); // calls function to determine which operation between newNum and number to do
                        this.line = newString(newNum,leftString,rightString); // creates a new string used in previous for loops to simplify the equation
                        j = -1; // restarts string from the beginning      
                        number = ""; // empty the number
                        leftString = ""; // empty the left string
                    }

                    // if the character is a digit or a '.' or it is a symbol but it is negative '-' or it is negative at the beginning "-2"
                    else if ((Char.IsDigit(this.line[j]) || this.line[j] == '.') || (j != 0 && (!Char.IsDigit(this.line[j - 1]) && this.line[j] == '-')) || (this.line[j] == '-' && j == 0))
                        number += this.line[j];                                   
                    else
                    {
                        number = ""; // wrong number to save in string so string must be empty again
                        leftString = "";
                        for (int m = 0; m < j+1; m++)
                            leftString += this.line[m]; // new leftString being created and increased because the operations being looked for wasn't found
                    }
                }
            }

            this.lower = this.line;
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }

        private void multiply(object sender, EventArgs e)
        {
            this.line += "*";
            this.upper = this.line;
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }

        private void minus(object sender, EventArgs e)
        {
            this.line += "-";
            this.upper = this.line;
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }

        private void plus(object sender, EventArgs e)
        {
            this.line += "+";
            this.upper = this.line;
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }

        private void divide(object sender, EventArgs e)
        {
            this.line += "/";
            this.upper = this.line;
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }

        private void percent(object sender, EventArgs e)
        {
            this.line += "%";
            this.upper = this.line;
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }

        private void intoNegative(object sender, EventArgs e)
        {
            this.line += "-";
            this.upper = this.line;
            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }

        private void AC(object sender, EventArgs e)
        {
            this.upper = "";
            this.lower = "";
            this.line = "";

            textBox1.Text = this.upper + Environment.NewLine + "--------------------" + Environment.NewLine + this.lower;
        }
    }
}
